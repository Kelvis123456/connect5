const { test, expect } = require('@playwright/test');
const path = require('path');
const fs = require('fs');

const screenshotsDir = path.join(__dirname, '..', 'Screenshots');
if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

test('Verify Skills.sh Home and Skill Pages', async ({ page }) => {
  // Test Home page
  await page.goto('https://www.skills.sh');
  await expect(page).toHaveTitle(/Skills/i);
  await page.screenshot({ path: path.join(screenshotsDir, 'home.png'), fullPage: true });

  // Test Brainstorming skill page
  await page.goto('https://www.skills.sh/obra/superpowers/brainstorming');
  const brainstormingHeading = page.locator('h1').first();
  await expect(brainstormingHeading).toContainText('brainstorming');
  await page.screenshot({ path: path.join(screenshotsDir, 'brainstorming.png'), fullPage: true });

  // Test Frontend Design skill page
  await page.goto('https://www.skills.sh/anthropics/skills/frontend-design');
  const frontendHeading = page.locator('h1').first();
  await expect(frontendHeading).toContainText('frontend-design');
  await page.screenshot({ path: path.join(screenshotsDir, 'frontend-design.png'), fullPage: true });
});
